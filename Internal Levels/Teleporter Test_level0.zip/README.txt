Level: Teleporter Test
Author: NellowTCS
Difficulty: Easy
Level ID: 0
Music File Required: ../Sound/Level Soundtracks/level2.ogg
Setup Instructions:
1. Extract all files from this zip
2. Copy "level0.js" to the Levels directory
The level will automatically appear in the menu when you restart the game.