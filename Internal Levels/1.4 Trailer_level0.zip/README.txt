Level: 1.4 Trailer
Author: NellowTCS
Difficulty: Easy
Level ID: 0
Music File Required: ../Sound/Level Soundtracks/1-01 Unity.m4a
Setup Instructions:
1. Extract all files from this zip
2. Copy "level0.js" to the Levels directory
3. Copy the music file to Sound/Level Soundtracks directory
The level will automatically appear in the menu when you restart the game.